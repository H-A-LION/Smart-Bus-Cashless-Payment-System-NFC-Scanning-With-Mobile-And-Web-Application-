import { db, getDoc, setDoc, collection, addDoc, getDocs,
   doc, updateDoc , serverTimestamp, query, where } from "../core/firebase.js";

import { initNfcTable } from "../modules/datatable.js";

let nfcTable;

const loadNfcCards = async () => {
  try {
    // Get all users who have NFC cards
    const usersQuery = query(collection(db, "users"), where("nfcCards", "!=", null));
    const querySnapshot = await getDocs(usersQuery);

    let allCards = [];
    for (const userDoc of querySnapshot.docs) {
      const userCards = userDoc.data().nfcCards || {};
      Object.entries(userCards).forEach(([cardId, cardData]) => {
        allCards.push({
          id: cardId,
          userId: userDoc.id,
          ...cardData
        });
      });
    }
    nfcTable.clear().rows.add(allCards).draw();
  } catch (error) {
    console.error("Error loading NFC cards:", error);
    alert("Failed to load NFC cards. Please try again.");
  }  
};

const addNfcCard = async (e) => {
  e.preventDefault();
  try {
    const cardId = document.getElementById('cardId').value.trim();
    const userId = document.getElementById('userId').value.trim();
    const balance = parseFloat(document.getElementById('balance').value) || 0;
    const isActive = document.getElementById('isActive').checked;

    if (!cardId) {
      alert("Card ID is required");
      return;
    }
    if (userId) {
      // Check if user exists
      const userRef = doc(db, "users", userId);
      const userDoc = await getDoc(userRef);
      
      if (!userDoc.exists()) {
        alert("User not found");
        return;
      }

      // Add card to user's NFC cards subcollection
      await updateDoc(userRef, {
        [`nfcCards.${cardId}`]: {
          balance,
          isActive,
          createdAt: serverTimestamp()
        }
      });
    } else {
      // Add unassigned card (store in a separate collection or admin user)
      await setDoc(doc(db, "unassignedCards", cardId), {
        balance,
        isActive,
        createdAt: serverTimestamp()
      });
    }
    document.getElementById('nfcModal').style.display = 'none';
    document.getElementById('nfcForm').reset();
    loadNfcCards();
  } catch (error) {
    console.error("Error adding NFC card:", error);
  }
};

const setupEventListeners = () => {
  // Add NFC Card button
  document.getElementById('addNfcBtn').addEventListener('click', () => {
    document.getElementById('nfcModal').style.display = 'block';
  });

  // NFC Form submission
  document.getElementById('nfcForm').addEventListener('submit', addNfcCard);

  // Cancel button
  document.getElementById('cancelNfcBtn').addEventListener('click', () => {
    document.getElementById('nfcModal').style.display = 'none';
    document.getElementById('nfcForm').reset();
  });

  // Edit/Delete buttons (using event delegation)
  document.getElementById('nfcTable').addEventListener('click', async (e) => {
    const editBtn = e.target.closest('.edit-btn');
    const deleteBtn = e.target.closest('.delete-btn');
    const chargeBtn = e.target.closest('.charge-btn');
    
    if (editBtn) {
      const cardId = editBtn.dataset.id;
      // Implement edit functionality
      console.log("Edit card:", cardId);
    }
    
    if (deleteBtn) {
      const cardId = deleteBtn.dataset.id;
      if (confirm(`Are you sure you want to delete card ${cardId}?`)) {
        try {
          // Find which user has this card
          const usersQuery = query(collection(db, "users"), where(`nfcCards.${cardId}`, "!=", null));
          const querySnapshot = await getDocs(usersQuery);
          
          if (!querySnapshot.empty) {
            const userDoc = querySnapshot.docs[0];
            await updateDoc(doc(db, "users", userDoc.id), {
              [`nfcCards.${cardId}`]: deleteField()
            });
            loadNfcCards();
          } else {
            // Check unassigned cards
            await deleteDoc(doc(db, "unassignedCards", cardId));
            loadNfcCards();
          }
        } catch (error) {
          console.error("Error deleting NFC card:", error);
          alert("Failed to delete NFC card. Please try again.");
        }
      }
    }
    
    if (chargeBtn) {
      const cardId = chargeBtn.dataset.id;
      // Implement charge functionality
      console.log("Charge card:", cardId);
    }
  });
};

export const initNfcPage = () => {
  nfcTable = initNfcTable();
  setupEventListeners();
  loadNfcCards();
};