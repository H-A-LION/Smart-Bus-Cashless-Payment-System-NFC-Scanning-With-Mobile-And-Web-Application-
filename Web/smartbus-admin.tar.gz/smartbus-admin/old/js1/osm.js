// js/osm.js
document.addEventListener('DOMContentLoaded', () => {
    // Initialize any OSM-specific functionality
    console.log("OSM Interface loaded");
    
    // You can add any initialization code needed for the OSM API interface
    // For example, checking authentication status or loading dynamic content
});