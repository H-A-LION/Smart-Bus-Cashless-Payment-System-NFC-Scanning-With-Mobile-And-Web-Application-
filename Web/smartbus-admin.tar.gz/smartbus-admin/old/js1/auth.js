import { initializeApp } from "https://www.gstatic.com/firebasejs/9.6.0/firebase-app.js";
import { 
  getAuth, 
  signInWithEmailAndPassword,
  signOut,
  onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/9.6.0/firebase-auth.js";
import { firebaseConfig } from "./firebase-config.js";

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

// Login Function
document.getElementById('loginForm')?.addEventListener('submit', async (e) => {
  e.preventDefault();
  
  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;
  
  try {
    await signInWithEmailAndPassword(auth, email, password);
    window.location.href = 'admin-dashboard.html';
  } catch (error) {
    alert('Login failed: ' + error.message);
  }
});

// Logout Function
document.getElementById('logoutBtn')?.addEventListener('click', async () => {
  try {
    await signOut(auth);
    window.location.href = 'index.html';
  } catch (error) {
    console.error('Logout error:', error);
  }
});

// Check Auth State
onAuthStateChanged(auth, (user) => {
  if (user && window.location.pathname.endsWith('index.html')) {
    window.location.href = 'admin-dashboard.html';
  }
  
  if (!user && !window.location.pathname.endsWith('index.html')) {
    window.location.href = 'index.html';
  }
  
  if (user) {
    document.getElementById('adminName')?.textContent = user.email;
  }
});