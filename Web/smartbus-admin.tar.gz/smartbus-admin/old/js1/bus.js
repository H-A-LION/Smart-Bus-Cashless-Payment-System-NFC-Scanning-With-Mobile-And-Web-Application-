import { db, rtdb } from "./firebase-config.js";
import { collection, addDoc, getDocs, doc, updateDoc, deleteDoc, serverTimestamp } from "https://www.gstatic.com/firebasejs/9.6.0/firebase-firestore.js";
import { ref, set } from "https://www.gstatic.com/firebasejs/9.6.0/firebase-database.js";

// Initialize DataTable
const busTable = $('#busTable').DataTable({
  columns: [
    { data: 'busId' },
    { 
      data: 'currentLocation', 
      render: data => data ? `${data.latitude}, ${data.longitude}` : 'N/A'
    },
    { 
      data: 'lastUpdated', 
      render: data => data ? new Date(data).toLocaleString() : 'Never'
    },
    {
      data: 'busId',
      render: (data) => `
        <button class="btn-action track-btn" data-id="${data}">
          <i class="fas fa-map-marker-alt"></i>
        </button>
        <button class="btn-action delete-btn" data-id="${data}">
          <i class="fas fa-trash"></i>
        </button>
      `
    }
  ]
});

// Load Buses
export const loadBuses = async () => {
  const querySnapshot = await getDocs(collection(db, "Buses"));
  const buses = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
  busTable.clear().rows.add(buses).draw();
};

// Add Bus
document.getElementById('addBusBtn').addEventListener('click', () => {
  document.getElementById('busModal').style.display = 'block';
});

document.getElementById('busForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const busId = document.getElementById('busId').value;
  
  // Add to Firestore
  await addDoc(collection(db, "Buses"), {
    busId,
    lastUpdated: serverTimestamp()
  });

  // Initialize Realtime DB node
  await set(ref(rtdb, `buses/${busId}`), {
    currentLocation: null,
    lastUpdated: Date.now()
  });

  loadBuses();
  document.getElementById('busModal').style.display = 'none';
});

// Initialize
document.addEventListener('DOMContentLoaded', loadBuses);