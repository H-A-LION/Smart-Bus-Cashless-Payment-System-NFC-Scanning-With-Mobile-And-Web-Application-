import { initializeApp } from "https://www.gstatic.com/firebasejs/9.6.0/firebase-app.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/9.6.0/firebase-firestore.js";
import { getDatabase } from "https://www.gstatic.com/firebasejs/9.6.0/firebase-database.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/9.6.0/firebase-auth.js";


const firebaseConfig = {
    apiKey: "AIzaSyCrCfIqGCkAmBO9UV_enQtIaL8lVRf1MzM",
    authDomain: "smartbus-cashless-payment-nfc.firebaseapp.com",
    databaseURL: "https://smartbus-cashless-payment-nfc-default-rtdb.firebaseio.com",
    projectId: "smartbus-cashless-payment-nfc",
    storageBucket: "smartbus-cashless-payment-nfc.firebasestorage.app",
    messagingSenderId: "577944959510",
    appId: "1:577944959510:web:96172f84f19cb6d3f1d337",
    measurementId: "G-KM9K4EWPP3"
  };


// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app); // Firestore
const rtdb = getDatabase(app); // Realtime Database
const auth = getAuth(app); // Authentication

export { db, rtdb, auth };