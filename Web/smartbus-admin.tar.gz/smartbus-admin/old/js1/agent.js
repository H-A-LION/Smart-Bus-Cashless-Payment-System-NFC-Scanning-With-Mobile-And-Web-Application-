// js/agent.js
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.6.0/firebase-app.js";
import { 
  getFirestore, collection, doc, getDoc, getDocs, 
  updateDoc, deleteDoc, onSnapshot, serverTimestamp
} from "https://www.gstatic.com/firebasejs/9.6.0/firebase-firestore.js";
import { firebaseConfig } from "./firebase-config.js";

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

// DOM Elements
const agentsTable = $('#agentsTable').DataTable({
  columns: [
    { data: 'id' },
    { data: 'name' },
    { data: 'email' },
    { data: 'phone' },
    { data: 'balance', render: data => `$${data.toFixed(2)}` },
    { 
      data: 'status',
      render: data => `<span class="status-badge ${data}">${data.charAt(0).toUpperCase() + data.slice(1)}</span>`
    },
    { 
      data: 'id',
      render: (data, type, row) => `
        <button class="btn-action edit-btn" data-id="${data}">
          <i class="fas fa-edit"></i>
        </button>
        <button class="btn-action charge-btn" data-id="${data}">
          <i class="fas fa-coins"></i>
        </button>
        <button class="btn-action delete-btn" data-id="${data}">
          <i class="fas fa-trash"></i>
        </button>
      `,
      orderable: false
    }
  ],
  pageLength: 10,
  responsive: true
});

const editAgentModal = document.getElementById('editAgentModal');
const chargeAgentModal = document.getElementById('chargeAgentModal');
const editAgentForm = document.getElementById('editAgentForm');
const chargeAgentForm = document.getElementById('chargeAgentForm');

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  setupEventListeners();
  loadAgents();
});

function setupEventListeners() {
  // Refresh button
  document.getElementById('refreshAgentsBtn').addEventListener('click', loadAgents);
  
  // Search input
  document.getElementById('agentSearch').addEventListener('input', (e) => {
    agentsTable.search(e.target.value).draw();
  });
  
  // Status filter
  document.getElementById('filterStatus').addEventListener('change', (e) => {
    agentsTable.column(5).search(e.target.value).draw();
  });
  
  // Table action buttons (using event delegation)
  document.getElementById('agentsTable').addEventListener('click', (e) => {
    const btn = e.target.closest('button');
    if (!btn) return;
    
    const agentId = btn.dataset.id;
    
    if (btn.classList.contains('edit-btn')) {
      showEditAgentModal(agentId);
    } else if (btn.classList.contains('charge-btn')) {
      showChargeAgentModal(agentId);
    } else if (btn.classList.contains('delete-btn')) {
      deleteAgent(agentId);
    }
  });
  
  // Modal close buttons
  document.querySelectorAll('.modal .close').forEach(btn => {
    btn.addEventListener('click', () => {
      editAgentModal.style.display = 'none';
      chargeAgentModal.style.display = 'none';
    });
  });
  
  // Cancel buttons
  document.getElementById('cancelEditBtn').addEventListener('click', () => {
    editAgentModal.style.display = 'none';
  });
  
  document.getElementById('cancelChargeBtn').addEventListener('click', () => {
    chargeAgentModal.style.display = 'none';
  });
  
  // Form submissions
  editAgentForm.addEventListener('submit', saveAgentChanges);
  chargeAgentForm.addEventListener('submit', processAgentCharge);
}

function loadAgents() {
  const agentsCol = collection(db, 'agents');
  
  onSnapshot(agentsCol, (snapshot) => {
    const agents = [];
    snapshot.forEach(doc => {
      agents.push({
        id: doc.id,
        ...doc.data()
      });
    });
    
    agentsTable.clear().rows.add(agents).draw();
    updatePaginationInfo();
  });
}

function updatePaginationInfo() {
  const info = agentsTable.page.info();
  document.getElementById('paginationInfo').textContent = 
    `Showing ${info.start + 1} to ${info.end} of ${info.recordsTotal} agents`;
}

async function showEditAgentModal(agentId) {
  const agentDoc = await getDoc(doc(db, 'agents', agentId));
  if (!agentDoc.exists()) return;
  
  const agent = agentDoc.data();
  
  document.getElementById('editAgentId').value = agentId;
  document.getElementById('editAgentName').value = agent.name || '';
  document.getElementById('editAgentEmail').value = agent.email || '';
  document.getElementById('editAgentPhone').value = agent.phone || '';
  document.getElementById('editAgentBalance').value = agent.balance || 0;
  document.getElementById('editAgentStatus').value = agent.status || 'active';
  
  editAgentModal.style.display = 'block';
}

async function saveAgentChanges(e) {
  e.preventDefault();
  
  const agentId = document.getElementById('editAgentId').value;
  const agentData = {
    name: document.getElementById('editAgentName').value,
    email: document.getElementById('editAgentEmail').value,
    phone: document.getElementById('editAgentPhone').value,
    balance: parseFloat(document.getElementById('editAgentBalance').value),
    status: document.getElementById('editAgentStatus').value,
    updatedAt: serverTimestamp()
  };
  
  try {
    await updateDoc(doc(db, 'agents', agentId), agentData);
    editAgentModal.style.display = 'none';
    alert('Agent updated successfully!');
  } catch (error) {
    console.error('Error updating agent:', error);
    alert('Error updating agent: ' + error.message);
  }
}

async function showChargeAgentModal(agentId) {
  const agentDoc = await getDoc(doc(db, 'agents', agentId));
  if (!agentDoc.exists()) return;
  
  const agent = agentDoc.data();
  
  document.getElementById('chargeAgentId').value = agentId;
  document.getElementById('chargeAmount').value = '';
  document.getElementById('chargeNotes').value = '';
  
  chargeAgentModal.style.display = 'block';
}

async function processAgentCharge(e) {
  e.preventDefault();
  
  const agentId = document.getElementById('chargeAgentId').value;
  const amount = parseFloat(document.getElementById('chargeAmount').value);
  const notes = document.getElementById('chargeNotes').value;
  
  if (isNaN(amount) || amount <= 0) {
    alert('Please enter a valid amount');
    return;
  }
  
  try {
    // Update agent balance
    const agentRef = doc(db, 'agents', agentId);
    await updateDoc(agentRef, {
      balance: increment(amount),
      updatedAt: serverTimestamp()
    });
    
    // Record transaction
    await addDoc(collection(db, 'transactions'), {
      userId: agentId,
      amount,
      type: 'charging',
      notes,
      timestamp: serverTimestamp()
    });
    
    chargeAgentModal.style.display = 'none';
    alert(`Successfully charged $${amount.toFixed(2)} to agent's balance`);
  } catch (error) {
    console.error('Error charging agent:', error);
    alert('Error charging agent: ' + error.message);
  }
}

async function deleteAgent(agentId) {
  if (!confirm('Are you sure you want to delete this agent?')) return;
  
  try {
    await deleteDoc(doc(db, 'agents', agentId));
    alert('Agent deleted successfully');
  } catch (error) {
    console.error('Error deleting agent:', error);
    alert('Error deleting agent: ' + error.message);
  }
}

// Helper function for Firestore increment
function increment(value) {
  return firebase.firestore.FieldValue.increment(value);
}