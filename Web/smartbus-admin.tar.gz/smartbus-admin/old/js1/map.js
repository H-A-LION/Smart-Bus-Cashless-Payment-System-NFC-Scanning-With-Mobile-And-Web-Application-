import { initializeApp } from "https://www.gstatic.com/firebasejs/9.6.0/firebase-app.js";
import { 
  getFirestore, collection, doc, getDoc, getDocs, 
  addDoc, updateDoc, deleteDoc, onSnapshot, serverTimestamp 
} from "https://www.gstatic.com/firebasejs/9.6.0/firebase-firestore.js";
import { 
  getDatabase, ref, onValue, update 
} from "https://www.gstatic.com/firebasejs/9.6.0/firebase-database.js";
import { firebaseConfig } from "./firebase-config.js";

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const rtdb = getDatabase(app);

// Map variables
let map;
let currentAction = new URLSearchParams(window.location.search).get('action');
let editMode = false;
let currentEditingStation = null;



// DOM Elements
const mapTitle = document.getElementById('mapTitle');
const mapSubtitle = document.getElementById('mapSubtitle');
const stationControls = document.getElementById('stationControls');
const busControls = document.getElementById('busControls');
const routeControls = document.getElementById('routeControls');
const routeSelector = document.getElementById('routeSelector');
const stationModal = document.getElementById('stationModal');
const modalTitle = document.getElementById('modalTitle');
const stationForm = document.getElementById('stationForm');
const stationRoute = document.getElementById('stationRoute');
const editSidebar = document.getElementById('editSidebar');
const closeSidebarBtn = document.getElementById('closeSidebar');
// Add to setupEventListeners()
closeSidebarBtn.addEventListener('click', closeSidebar);
document.getElementById('stationEditForm').addEventListener('submit', saveStationEdits);
document.getElementById('deleteStationBtn').addEventListener('click', confirmDeleteStation);


// Initialize the map when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  initMap();
  setupUI();
  loadRoutes();
  
  switch(currentAction) {
    case 'stations':
      setupStationManagement();
      break;
    case 'buses':
      setupBusTracking();
      break;
    case 'routes':
      setupRouteViewing();
      break;
    default:
      window.location.href = 'osm-api.html';
  }
});

function initMap() {
  // Default to Addis Ababa coordinates
  map = L.map('map').setView([9.005401, 38.763611], 13);
  
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
  }).addTo(map);
}

function setupUI() {
  // Set title based on action
  switch(currentAction) {
    case 'stations':
      mapTitle.textContent = 'Station Management';
      mapSubtitle.textContent = 'Add, edit or remove bus stations';
      break;
    case 'buses':
      mapTitle.textContent = 'Bus Tracking';
      mapSubtitle.textContent = 'View real-time bus locations';
      break;
    case 'routes':
      mapTitle.textContent = 'Route Viewing';
      mapSubtitle.textContent = 'View and analyze bus routes';
      break;
  }
}

async function loadRoutes() {
  const routesSnapshot = await getDocs(collection(db, 'routes'));
  routeSelector.innerHTML = '<option value="">Select a route</option>';
  stationRoute.innerHTML = '<option value="">Select a route</option>';
  
  routesSnapshot.forEach(doc => {
    const route = doc.data();
    const option = document.createElement('option');
    option.value = doc.id;
    option.textContent = `${route.name} (${route.direction})`;
    routeSelector.appendChild(option.cloneNode(true));
    stationRoute.appendChild(option);
  });
}

function setupStationManagement() {
  stationControls.style.display = 'block';
  
  // Load and display stations
  onSnapshot(collection(db, 'stations'), (snapshot) => {
    snapshot.docChanges().forEach(change => {
      if (change.type === 'added' || change.type === 'modified') {
        updateStationOnMap(change.doc.id, change.doc.data());
      } else if (change.type === 'removed') {
        removeStationFromMap(change.doc.id);
      }
    });
  });

  // Setup station modal
  document.getElementById('addStationBtn').addEventListener('click', showAddStationModal);
  document.getElementById('editStationsBtn').addEventListener('click', toggleEditMode);
  document.querySelector('.close').addEventListener('click', () => stationModal.style.display = 'none');
  document.getElementById('cancelStationBtn').addEventListener('click', () => stationModal.style.display = 'none');
  stationForm.addEventListener('submit', saveStation);
}

function setupBusTracking() {
  busControls.style.display = 'block';
  
  // Load and display buses in real-time
  const busesRef = ref(rtdb, 'buses');
  onValue(busesRef, (snapshot) => {
    const buses = snapshot.val() || {};
    Object.entries(buses).forEach(([busId, busData]) => {
      updateBusOnMap(busId, busData);
    });
  });

  document.getElementById('refreshBusesBtn').addEventListener('click', () => {
    // Force refresh by re-subscribing to the data
    onValue(busesRef, (snapshot) => {
      const buses = snapshot.val() || {};
      Object.entries(buses).forEach(([busId, busData]) => {
        updateBusOnMap(busId, busData);
      });
    });
  });
}

function setupRouteViewing() {
  routeControls.style.display = 'block';
  
  routeSelector.addEventListener('change', (e) => {
    const routeId = e.target.value;
    if (routeId) {
      displayRoute(routeId);
    }
  });
}

// Station management functions
function updateStationOnMap(stationId, stationData) {
  const marker = L.marker([stationData.location.latitude, stationData.location.longitude], {
    stationId,
    draggable: editMode
  }).addTo(map);
  
  marker.bindPopup(`
    <b>${stationData.name}</b><br>
    ${getRouteName(stationData.routeId)}
    ${editMode ? `
    <div class="popup-actions">
      <button onclick="editStation('${stationId}')">Edit</button>
      <button onclick="deleteStation('${stationId}')">Delete</button>
    </div>
    ` : ''}
  `);
  
  if (editMode) {
    marker.on('dragend', function(e) {
      updateStationPosition(stationId, e.target.getLatLng());
    });
  }
}

async function getRouteName(routeId) {
  if (!routeId) return '';
  const routeDoc = await getDoc(doc(db, 'routes', routeId));
  return routeDoc.exists() ? `Route: ${routeDoc.data().name}` : '';
}

function removeStationFromMap(stationId) {
  const marker = map.eachLayer(layer => {
    if (layer.options?.stationId === stationId) {
      map.removeLayer(layer);
    }
  });
}

function showAddStationModal() {
  currentEditingStation = null;
  modalTitle.textContent = 'Add New Station';
  stationForm.reset();
  
  const center = map.getCenter();
  document.getElementById('stationLat').value = center.lat.toFixed(6);
  document.getElementById('stationLng').value = center.lng.toFixed(6);
  
  stationModal.style.display = 'block';
}

function toggleEditMode() {
  editMode = !editMode;
  const btn = document.getElementById('editStationsBtn');
  
  if (editMode) {
    btn.classList.add('active');
    btn.innerHTML = '<i class="fas fa-check"></i> Done Editing';
    
    // Enable dragging for all station markers
    map.eachLayer(layer => {
      if (layer.options?.stationId) {
        layer.dragging.enable();
        layer.on('dragend', function(e) {
          updateStationPosition(layer.options.stationId, e.target.getLatLng());
        });
      }
    });
  } else {
    btn.classList.remove('active');
    btn.innerHTML = '<i class="fas fa-edit"></i> Edit Stations';
    
    // Disable dragging for all station markers
    map.eachLayer(layer => {
      if (layer.options?.stationId) {
        layer.dragging.disable();
      }
    });
  }
}

async function saveStation(e) {
  e.preventDefault();
  
  const stationData = {
    name: document.getElementById('stationName').value,
    routeId: document.getElementById('stationRoute').value,
    location: {
      latitude: parseFloat(document.getElementById('stationLat').value),
      longitude: parseFloat(document.getElementById('stationLng').value)
    },
    updatedAt: serverTimestamp()
  };
  
  try {
    if (currentEditingStation) {
      // Update existing station
      await updateDoc(doc(db, 'stations', currentEditingStation), stationData);
    } else {
      // Add new station
      stationData.createdAt = serverTimestamp();
      await addDoc(collection(db, 'stations'), stationData);
    }
    
    stationModal.style.display = 'none';
    alert('Station saved successfully!');
  } catch (error) {
    console.error('Error saving station:', error);
    alert('Error saving station: ' + error.message);
  }
}

async function updateStationPosition(stationId, latLng) {
  try {
    await updateDoc(doc(db, 'stations', stationId), {
      'location.latitude': latLng.lat,
      'location.longitude': latLng.lng,
      updatedAt: serverTimestamp()
    });
  } catch (error) {
    console.error('Error updating station position:', error);
  }
}

// Bus tracking functions
function updateBusOnMap(busId, busData) {
  // Remove existing bus marker if it exists
  map.eachLayer(layer => {
    if (layer.options?.busId === busId) {
      map.removeLayer(layer);
    }
  });
  
  if (busData.currentLocation && busData.currentLocation.latitude) {
    const marker = L.circleMarker(
      [busData.currentLocation.latitude, busData.currentLocation.longitude], 
      {
        radius: 8,
        fillColor: "#0d6efd",
        color: "#fff",
        weight: 2,
        opacity: 1,
        fillOpacity: 0.8,
        busId
      }
    ).addTo(map);
    
    marker.bindPopup(`
      <b>Bus ${busId}</b><br>
      Driver: ${busData.driverName || 'Unknown'}<br>
      Status: ${busData.status || 'Unknown'}<br>
      Last update: ${new Date(busData.currentLocation.timestamp).toLocaleString()}
    `);
  }
}

// Route viewing functions
async function displayRoute(routeId) {
  // Clear existing route layers
  map.eachLayer(layer => {
    if (layer.options?.isRouteLayer) {
      map.removeLayer(layer);
    }
  });
  
  const routeDoc = await getDoc(doc(db, 'routes', routeId));
  if (!routeDoc.exists()) return;
  
  const route = routeDoc.data();
  const stations = [];
  
  // Get all stations for this route
  for (const stationId of route.stations) {
    const stationDoc = await getDoc(doc(db, 'stations', stationId));
    if (stationDoc.exists()) {
      stations.push(stationDoc.data().location);
    }
  }
  
  // Draw the route path
  if (stations.length > 1) {
    const routePath = L.polyline(
      stations.map(s => [s.latitude, s.longitude]),
      { color: '#ff7800', weight: 5, isRouteLayer: true }
    ).addTo(map);
    
    // Fit the map to the route bounds
    map.fitBounds(routePath.getBounds());
  }
}

// Make functions available globally for popup buttons
window.editStation = async function(stationId) {
  const stationDoc = await getDoc(doc(db, 'stations', stationId));
  if (!stationDoc.exists()) return;
  
  currentEditingStation = stationId;
  modalTitle.textContent = 'Edit Station';
  
  const station = stationDoc.data();
  document.getElementById('stationName').value = station.name;
  document.getElementById('stationRoute').value = station.routeId || '';
  document.getElementById('stationLat').value = station.location.latitude;
  document.getElementById('stationLng').value = station.location.longitude;
  
  stationModal.style.display = 'block';
};

window.deleteStation = function(stationId) {
  if (confirm('Are you sure you want to delete this station?')) {
    deleteDoc(doc(db, 'stations', stationId))
      .then(() => alert('Station deleted successfully'))
      .catch(error => {
        console.error('Error deleting station:', error);
        alert('Error deleting station: ' + error.message);
      });
  }
};


// Add these new functions
function openSidebar(stationId, stationData) {
  currentEditingStation = stationId;
  document.getElementById('editStationId').value = stationId;
  document.getElementById('editStationName').value = stationData.name || '';
  document.getElementById('editStationRoute').value = stationData.routeId || '';
  
  // Populate route dropdown
  populateRouteDropdown('editStationRoute', stationData.routeId);
  
  editSidebar.classList.add('open');
  document.getElementById('map').classList.add('sidebar-open');
}

function closeSidebar() {
  editSidebar.classList.remove('open');
  document.getElementById('map').classList.remove('sidebar-open');
  currentEditingStation = null;
}

function populateRouteDropdown(selectId, selectedRouteId = '') {
  const select = document.getElementById(selectId);
  select.innerHTML = '<option value="">Select Route</option>';
  
  getDocs(collection(db, 'routes')).then(snapshot => {
    snapshot.forEach(doc => {
      const option = document.createElement('option');
      option.value = doc.id;
      option.textContent = doc.data().name;
      option.selected = doc.id === selectedRouteId;
      select.appendChild(option);
    });
  });
}

async function saveStationEdits(e) {
  e.preventDefault();
  
  const stationData = {
    name: document.getElementById('editStationName').value,
    routeId: document.getElementById('editStationRoute').value,
    updatedAt: serverTimestamp()
  };
  
  try {
    await updateDoc(doc(db, 'stations', currentEditingStation), stationData);
    closeSidebar();
    alert('Station updated successfully!');
  } catch (error) {
    console.error('Error updating station:', error);
    alert('Error updating station: ' + error.message);
  }
}

function confirmDeleteStation() {
  if (confirm('Are you sure you want to delete this station?')) {
    deleteDoc(doc(db, 'stations', currentEditingStation))
      .then(() => {
        closeSidebar();
        alert('Station deleted successfully');
      })
      .catch(error => {
        console.error('Error deleting station:', error);
        alert('Error deleting station: ' + error.message);
      });
  }
}

// Update your station click handler
function setupMapClickHandlers() {
  map.on('click', function(e) {
    if (editMode) {
      // Open sidebar for new station
      currentEditingStation = null;
      document.getElementById('editStationId').value = '';
      document.getElementById('editStationName').value = '';
      document.getElementById('editStationRoute').value = '';
      document.getElementById('stationLat').value = e.latlng.lat;
      document.getElementById('stationLng').value = e.latlng.lng;
      openSidebar();
    }
  });
}