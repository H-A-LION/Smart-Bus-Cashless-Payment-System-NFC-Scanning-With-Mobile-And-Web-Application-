import { db } from "./firebase-config.js";
import { collection, addDoc, getDocs, doc, updateDoc, deleteDoc, serverTimestamp } from "https://www.gstatic.com/firebasejs/9.6.0/firebase-firestore.js";

// Initialize DataTable
const nfcTable = $('#nfcTable').DataTable({
  columns: [
    { data: 'cardId' },
    { data: 'userId', defaultContent: 'N/A' },
    { 
      data: 'balance', 
      render: data => `$${data?.toFixed(2) || '0.00'}`
    },
    { 
      data: 'isActive', 
      render: data => `<span class="status-badge ${data ? 'active' : 'inactive'}">${data ? 'Active' : 'Inactive'}</span>`
    },
    {
      data: 'cardId',
      render: (data) => `
        <button class="btn-action edit-btn" data-id="${data}">
          <i class="fas fa-edit"></i>
        </button>
        <button class="btn-action delete-btn" data-id="${data}">
          <i class="fas fa-trash"></i>
        </button>
      `
    }
  ]
});

// Load NFC Cards
export const loadNfcCards = async () => {
  const querySnapshot = await getDocs(collection(db, "cards"));
  const cards = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
  nfcTable.clear().rows.add(cards).draw();
};

// Add NFC Card
document.getElementById('addNfcBtn').addEventListener('click', () => {
  document.getElementById('nfcModal').style.display = 'block';
});

document.getElementById('nfcForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  await addDoc(collection(db, "cards"), {
    cardId: document.getElementById('cardId').value,
    userId: document.getElementById('userId').value || null,
    balance: 0,
    isActive: false,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp()
  });
  loadNfcCards();
  document.getElementById('nfcModal').style.display = 'none';
});

// Initialize
document.addEventListener('DOMContentLoaded', loadNfcCards);